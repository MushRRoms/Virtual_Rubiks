#include <stdio.h>
#include "rubiks.h"

//PROTOTYPES RESOLUTION ALGORITHM
void white_UP(Side *rubiks);
void first_cross(Side *rubiks);
int perfect_cross_verifie(Side *cube);
void white_corners(Side *rubiks);
void turn_white_corner(Side *frontF, Side *rightF, Side *cube);
int verifie_corner(Side *rubiks);
void second_crown(Side *rubiks);
void left_move (Side *rubiks);
void right_move (Side *rubiks);
int verifie_second_crown(Side *cube);
void yellow_cross(Side *rubiks);
int yellow_cross_verifie(Side *cube);
int yellow_cross_branch (T_COLOR frontCol, T_COLOR rightCol, T_COLOR backCol, T_COLOR leftCol, Side *cube);
void yellow_corners (Side *rubiks);
int verifie_yellow_corners (Side *cube);
void place_corners(T_COLOR upF, T_COLOR frontF, Side *cube);
void turn_yellow_corners(Side *rubiks);
void main_algo(Side *cube);
void Menu(Side *rubiks);
void move_rubiks (Side *rubiks);
void fill_rubiks(Side *rubiks);
int cell_empty(Side *cube);

int main () {
    Side *rubiks = create_rubiks();
    int Haut = side_to_index(RIGHT, rubiks);
    init_rubiks(rubiks);
    display_rubiks(rubiks);
    Menu(rubiks);
    free_rubiks(rubiks);
    return 0;
}

//RESOLUTION ALGORITHM
//put the white face on the UP face
void white_UP(Side *rubiks){
    int whiteF;
    for (whiteF = 0;whiteF < 6;whiteF++){
        if ((rubiks + whiteF)->color[1][1] == W){
            break;
        }
    }

    switch ((rubiks + whiteF)->face){
    case LEFT:
        half_horizontal_rotation_anticlockwise(rubiks);
        half_vertical_rotation_anticlockwise(rubiks);
        break;
    case FRONT:
        half_vertical_rotation_anticlockwise(rubiks);
        break;
    case RIGHT:
        half_horizontal_rotation_clockwise(rubiks);
        half_vertical_rotation_anticlockwise(rubiks);
        break;
    case BACK:
        half_vertical_rotation_clockwise(rubiks);
        break;
    case DOWN:
        vertical_rotation(rubiks);
        break;
    }

    while ((rubiks + side_to_index(FRONT, rubiks))->color[1][1] != G){
        half_horizontal_rotation_clockwise(rubiks);
    }
}

//make the first perfect cross
void first_cross(Side *rubiks){
    int upF = side_to_index(UP, rubiks);
    int downF = side_to_index(DOWN, rubiks);
    for (int i = 0;i < 4;i++){
        if ((rubiks + upF)->color[0][1] == W){
            switch ((rubiks + side_to_index(BACK, rubiks))->color[0][1]){
            case O:
                UP_anticlockwise(1, rubiks);
                break;
            case R:
                UP_clockwise(1, rubiks);
                break;
            case G:
                UP_clockwise(2, rubiks);
                break;
            }
            break;
        } else {
            UP_anticlockwise(1, rubiks);
        }
    }
    int bugSaver = 0;
    while (perfect_cross_verifie(rubiks) && bugSaver <=100){
        int frontF = side_to_index(FRONT, rubiks);
        if ((rubiks + side_to_index(DOWN, rubiks))->color[0][1] == W){
            LEFT_anticlockwise(1, rubiks);
            RIGHT_clockwise(1, rubiks);
            DOWN_anticlockwise(1, rubiks);
            LEFT_clockwise(1, rubiks);
            RIGHT_anticlockwise(1, rubiks);
            if ((rubiks + side_to_index(DOWN, rubiks))->color[1][2] == (rubiks + frontF)->color[1][1]){
                DOWN_anticlockwise(1, rubiks);
            }
        }
        for (int i = 0;i < 3;i++){
            if ((rubiks + side_to_index(i, rubiks))->color[2][1] == W){
                switch (i){
                case 0:
                    if ((rubiks + side_to_index(DOWN, rubiks))->color[1][0] == (rubiks + frontF)->color[1][1]){
                        DOWN_clockwise(1, rubiks);
                    }
                    break;
                case 1:
                    if ((rubiks + side_to_index(DOWN, rubiks))->color[2][1] == (rubiks + frontF)->color[1][1]){
                        DOWN_clockwise(2, rubiks);
                    }
                    break;
                case 2:
                    if ((rubiks + side_to_index(DOWN, rubiks))->color[1][2] == (rubiks + frontF)->color[1][1]){
                        DOWN_anticlockwise(1, rubiks);
                    }
                }
            }
        }

        if ((rubiks + upF)->color[2][1] == W && (rubiks + frontF)->color[0][1] == (rubiks + frontF)->color[1][1]){
            if ((rubiks + frontF)->color[2][1] == W){
                DOWN_clockwise(1, rubiks);
            }
            if ((rubiks + frontF)->color[1][0] == W && (rubiks + side_to_index(LEFT, rubiks))->color[1][2] != (rubiks + side_to_index(LEFT, rubiks))->color[1][1]){
                FRONT_anticlockwise(1, rubiks);
                DOWN_clockwise(1, rubiks);
                FRONT_clockwise(1, rubiks);
            } else if((rubiks + frontF)->color[1][0] == W){
                LEFT_anticlockwise(1, rubiks);
            }
            if ((rubiks + frontF)->color[1][2] == W){
                if ((rubiks + side_to_index(RIGHT, rubiks))->color[1][0] != (rubiks + side_to_index(RIGHT, rubiks))->color[1][1]){
                    FRONT_clockwise(1, rubiks);
                    DOWN_clockwise(1, rubiks);
                    FRONT_anticlockwise(1, rubiks);
                } else {
                    RIGHT_clockwise(1, rubiks);
                }
            }
        } else {
            if ((rubiks + frontF)->color[1][2] == (rubiks + frontF)->color[1][1] && (rubiks + side_to_index(RIGHT, rubiks))->color[1][0] == W){
                FRONT_anticlockwise(1, rubiks);
            } else if ((rubiks + frontF)->color[1][2] == (rubiks + frontF)->color[1][1] && (rubiks + side_to_index(DOWN, rubiks))->color[0][1] == W){
                FRONT_anticlockwise(2, rubiks);
            } else if ((rubiks + side_to_index(RIGHT, rubiks))->color[0][1] == W && (rubiks + upF)->color[1][2] == (rubiks + side_to_index(LEFT, rubiks))->color[1][1]){
                RIGHT_anticlockwise(1, rubiks);
                FRONT_anticlockwise(1, rubiks);
                UP_clockwise(1, rubiks);
            } else if ((rubiks + frontF)->color[0][1] == W && (rubiks + upF)->color[2][1] == (rubiks + side_to_index(RIGHT, rubiks))->color[1][1]){
                FRONT_clockwise(1, rubiks);
                RIGHT_clockwise(1, rubiks);
            } else if ((rubiks + frontF)->color[0][1] == W && (rubiks + upF)->color[2][1] == (rubiks + frontF)->color[1][1]){
                FRONT_clockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
                RIGHT_clockwise(1, rubiks);
                UP_clockwise(1, rubiks);
            } else if ((rubiks + frontF)->color[2][1] == W && (rubiks + side_to_index(DOWN, rubiks))->color[0][1] == (rubiks + frontF)->color[1][1]){
                FRONT_anticlockwise(1, rubiks);
                RIGHT_anticlockwise(1, rubiks);
                DOWN_anticlockwise(1, rubiks);
                RIGHT_clockwise(1, rubiks);
                FRONT_anticlockwise(2, rubiks);
            } else if ((rubiks + frontF)->color[1][2] == W){
                if ((rubiks + side_to_index(RIGHT, rubiks))->color[1][0] == (rubiks + frontF)->color[1][1]){
                    RIGHT_anticlockwise(1, rubiks);
                    DOWN_anticlockwise(1, rubiks);
                    RIGHT_clockwise(1, rubiks);
                    FRONT_anticlockwise(2, rubiks);
                } else if ((rubiks + side_to_index(RIGHT, rubiks))->color[1][0] == (rubiks + side_to_index(RIGHT, rubiks))->color[1][1]){
                    RIGHT_clockwise(1, rubiks);
                }
            }
            if ((rubiks + frontF)->color[1][0] == W && (rubiks + side_to_index(LEFT, rubiks))->color[1][2] == (rubiks + frontF)->color[1][1]){
                FRONT_anticlockwise(1, rubiks);
            }
            if ((rubiks + frontF)->color[0][1] == W){
                    FRONT_clockwise(2, rubiks);
            }
            if ((rubiks + upF)->color[2][1] == W && (rubiks + frontF)->color[0][1] == (rubiks + frontF)->color[1][1]){
                if ((rubiks + frontF)->color[2][1] == W){
                    DOWN_clockwise(1, rubiks);
                }
                if ((rubiks + frontF)->color[1][0] == W && (rubiks + side_to_index(LEFT, rubiks))->color[1][2] != (rubiks + side_to_index(LEFT, rubiks))->color[1][1]){
                    FRONT_anticlockwise(1, rubiks);
                    DOWN_clockwise(1, rubiks);
                    FRONT_clockwise(1, rubiks);
                } else if((rubiks + frontF)->color[1][0] == W){
                    LEFT_anticlockwise(1, rubiks);
                }
                if ((rubiks + frontF)->color[1][2] == W && (rubiks + side_to_index(RIGHT, rubiks))->color[1][0] != (rubiks + side_to_index(RIGHT, rubiks))->color[1][1]){
                    FRONT_clockwise(1, rubiks);
                    DOWN_clockwise(1, rubiks);
                    FRONT_anticlockwise(1, rubiks);
                } 
            }
        }
        ++bugSaver;    
        half_horizontal_rotation_clockwise(rubiks);
    }
    if (bugSaver > 100){
        printf("\n\nSomething went wrong with the cross !\n\n");
    }

}

//search if a cross is done on the face
int perfect_cross_verifie(Side *cube){
    Side *upCross = (cube + side_to_index(UP, cube));
    if (upCross->color[0][1] == upCross->color[1][1] && upCross->color[1][0] == upCross->color[1][1] && upCross->color[2][1] == upCross->color[1][1] && upCross->color[1][2] == upCross->color[1][1]){
        return 0;
    } else {
        return 1;
    }
}

//make the white corners and the first crown
void white_corners(Side *rubiks){
    Side *upF = (rubiks + side_to_index(UP, rubiks));
    Side *downF = (rubiks + side_to_index(DOWN, rubiks));
    int bugSaver = 0;
    while (!verifie_corner(rubiks) && bugSaver <= 100){
        Side *frontF = (rubiks + side_to_index(FRONT, rubiks));
        Side *rightF = (rubiks + side_to_index(RIGHT, rubiks));
        if (frontF->color[0][2] == frontF->color[1][1] && rightF->color[0][0] == rightF->color[1][1] && upF->color[2][2] == W){
            ;
        } else if ((frontF->color[0][2] == rightF->color[1][1] || frontF->color[0][2] == W) && (rightF->color[0][0] == frontF->color[1][1] || rightF->color[0][0] == W) && (upF->color[2][2] == frontF->color[1][1] || upF->color[2][2] == rightF->color[1][1])){
            turn_white_corner(rubiks + side_to_index(FRONT, rubiks),rubiks + side_to_index(RIGHT, rubiks),rubiks);
        } else if (frontF->color[0][2] == W || rightF->color[0][0] == W || upF->color[2][2] == W){
            RIGHT_anticlockwise(1, rubiks);
            DOWN_anticlockwise(1, rubiks);
            RIGHT_clockwise(1, rubiks);
            DOWN_clockwise(1, rubiks);
        } else {
            int turn = 0;
            for(int i = 0;i < 4;i++){
                if ((frontF->color[2][2] == rightF->color[1][1] || frontF->color[2][2] == frontF->color[1][1] || frontF->color[2][2] == W) && (rightF->color[2][0] == frontF->color[1][1] || rightF->color[2][0] == rightF->color[1][1] || rightF->color[2][0] == W) && (downF->color[0][2] == frontF->color[1][1] || downF->color[0][2] == rightF->color[1][1] || downF->color[0][2] == W)){
                    turn_white_corner(rubiks + side_to_index(FRONT, rubiks),rubiks + side_to_index(RIGHT, rubiks),rubiks);
                    break; 
                }
                DOWN_anticlockwise(1, rubiks);
            }
        }
        half_horizontal_rotation_clockwise(rubiks);
        ++bugSaver;
    }
    if (bugSaver > 100){
        printf("\n\nSomething went wrong with the white corner!\n\n");
    }
}

//turn white corner
void turn_white_corner(Side *frontF, Side *rightF, Side *cube){
    while ((cube + side_to_index(UP, cube))->color[2][2] != W || frontF->color[0][2] != frontF->color[1][1] || rightF->color[0][0] != rightF->color[1][1]){
        RIGHT_anticlockwise(1, cube);
        DOWN_anticlockwise(1, cube);
        RIGHT_clockwise(1, cube);
        DOWN_clockwise(1, cube);
    }
}

//verifie if the corners are well placed
int verifie_corner(Side *rubiks){
    Side *upF = (rubiks + side_to_index(UP, rubiks));
    if (upF->color[0][1] == upF->color[1][1] && upF->color[1][0] == upF->color[1][1] && upF->color[2][0] == upF->color[1][1] && upF->color[2][2] == upF->color[1][1]){
        for (int i = 0;i < 4; i++){
            Side *face = (rubiks + side_to_index(i, rubiks));
            if (face->color[0][0] != face->color[0][2]){
                return 0;
            } else if (i == 3){
                return 1;
            }
        }
    }
    return 0;
}

//make the second crown
void second_crown(Side *rubiks){
    Side *upF = (rubiks + side_to_index(UP, rubiks));
    int bugSaver = 0;
    while (!verifie_second_crown(rubiks) && bugSaver <= 100){
        Side *frontF = (rubiks + side_to_index(FRONT, rubiks));
        Side *leftF = (rubiks + side_to_index(LEFT, rubiks));
        Side *rightF = (rubiks + side_to_index(RIGHT, rubiks));
        for (int i = 0;i < 4;i++){
            if (frontF->color[0][1] == frontF->color[1][1] && upF->color[2][1] == rightF->color[1][1]){
                right_move(rubiks);
            } else if (frontF->color[0][1] == frontF->color[1][1] && upF->color[2][1] == leftF->color[1][1]){
                left_move(rubiks);
            }
            if (frontF->color[1][2] == rightF->color[1][1] && rightF->color[1][0] == frontF->color[1][1]){
                UP_clockwise(1, rubiks);
                RIGHT_clockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
                RIGHT_anticlockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
                FRONT_anticlockwise(1, rubiks);
                UP_clockwise(1, rubiks);
                FRONT_clockwise(1, rubiks);
                UP_clockwise(2, rubiks);
                right_move(rubiks);
            }
            UP_clockwise(1, rubiks);
        }
        half_horizontal_rotation_clockwise(rubiks);
        ++bugSaver;
    }
}

//right move to make the second crown
void left_move (Side *rubiks){
    UP_anticlockwise(1, rubiks);
    LEFT_anticlockwise(1, rubiks);
    UP_clockwise(1, rubiks);
    LEFT_clockwise(1, rubiks);
    UP_clockwise(1, rubiks);
    FRONT_clockwise(1, rubiks);
    UP_anticlockwise(1, rubiks);
    FRONT_anticlockwise(1, rubiks);
}

//right move to make the second crown
void right_move (Side *rubiks){
    UP_clockwise(1, rubiks);
    RIGHT_clockwise(1, rubiks);
    UP_anticlockwise(1, rubiks);
    RIGHT_anticlockwise(1, rubiks);
    UP_anticlockwise(1, rubiks);
    FRONT_anticlockwise(1, rubiks);
    UP_clockwise(1, rubiks);
    FRONT_clockwise(1, rubiks);
}

//verifie if the second crown is done
int verifie_second_crown(Side *cube){
    Side *frontF = (cube + side_to_index(FRONT, cube));
    Side *leftF = (cube + side_to_index(LEFT, cube));
    Side *rightF = (cube + side_to_index(RIGHT, cube));
    Side *backF = (cube + side_to_index(BACK, cube));
    if (frontF->color[1][0] != frontF->color[1][1] || frontF->color[1][2] != frontF->color[1][1] || leftF->color[1][2] != leftF->color[1][1] || leftF->color[1][0] != leftF->color[1][1] || rightF->color[1][2] != rightF->color[1][1] || rightF->color[1][0] != rightF->color[1][1]){
        return 0;
    }
    return 1;
}

//make the yellow cross
void yellow_cross(Side *rubiks){
    Side *upF = (rubiks + side_to_index(UP, rubiks));
    int bugSaver = 0;
    while (!yellow_cross_verifie(rubiks) && bugSaver <= 100){
        Side *leftF = (rubiks + side_to_index(LEFT, rubiks));
        Side *frontF = (rubiks + side_to_index(FRONT, rubiks));
        Side *rightF = (rubiks + side_to_index(RIGHT, rubiks));
        Side *backF = (rubiks + side_to_index(BACK, rubiks));
        if (!perfect_cross_verifie(rubiks) && frontF->color[0][1] == (3 - backF->color[0][1]) && yellow_cross_branch(frontF->color[0][1], rightF->color[0][1], backF->color[0][1], leftF->color[0][1], rubiks)){
            while (frontF->color[0][1] != frontF->color[1][1]){
                UP_anticlockwise(1, rubiks);
                half_horizontal_rotation_clockwise(rubiks);
            }
        } else {
            if (!perfect_cross_verifie(rubiks) && backF->color[0][1] == (3 - frontF->color[0][1])){
                while (frontF->color[0][1] != frontF->color[1][1]){
                    UP_anticlockwise(1, rubiks);
                    half_horizontal_rotation_clockwise(rubiks);
                }
                RIGHT_clockwise(1, rubiks);
                UP_clockwise(2, rubiks);
                RIGHT_anticlockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
                RIGHT_clockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
                RIGHT_anticlockwise(1, rubiks);
            } else if (!perfect_cross_verifie(rubiks) && yellow_cross_branch(frontF->color[0][1], rightF->color[0][1], backF->color[0][1], leftF->color[0][1], rubiks)){
                while (leftF->color[0][1] != leftF->color[1][1]){
                    UP_anticlockwise(1, rubiks);
                    half_horizontal_rotation_clockwise(rubiks);
                }
                RIGHT_clockwise(1, rubiks);
                UP_clockwise(2, rubiks);
                RIGHT_anticlockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
                RIGHT_clockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
                RIGHT_anticlockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
            } else if (upF->color[0][1] != Y && upF->color[1][0] != Y && upF->color[1][2] != Y && upF->color[2][1] != Y){
                RIGHT_anticlockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
                FRONT_anticlockwise(1, rubiks);
                UP_clockwise(1, rubiks);
                FRONT_clockwise(1, rubiks);
                RIGHT_clockwise(1, rubiks);
                FRONT_clockwise(1, rubiks);
                RIGHT_clockwise(1, rubiks);
                UP_clockwise(1, rubiks);
                RIGHT_anticlockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
                FRONT_anticlockwise(1, rubiks);
            } else if (upF->color[0][1] == Y && upF->color[1][0] == Y){
                RIGHT_anticlockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
                FRONT_anticlockwise(1, rubiks);
                UP_clockwise(1, rubiks);
                FRONT_clockwise(1, rubiks);
                RIGHT_clockwise(1, rubiks);
            } else if (upF->color[1][0] == Y && upF->color[1][2] == Y){
                FRONT_clockwise(1, rubiks);
                RIGHT_clockwise(1, rubiks);
                UP_clockwise(1, rubiks);
                RIGHT_anticlockwise(1, rubiks);
                UP_anticlockwise(1, rubiks);
                FRONT_anticlockwise(1, rubiks);
            }
        }
        half_horizontal_rotation_clockwise(rubiks);
        ++bugSaver;
    }

    if (bugSaver > 100){
        printf("\n\nSomething went wrong with the yellow cross !\n\n");
    }
}

//verifie if the yellow cross is done
int yellow_cross_verifie(Side *cube){
    Side *upF = (cube + side_to_index(UP, cube));
    Side *leftF = (cube + side_to_index(LEFT, cube));
    Side *frontF = (cube + side_to_index(FRONT, cube));
    Side *rightF = (cube + side_to_index(RIGHT, cube));
    Side *backF = (cube + side_to_index(BACK, cube));
    if (upF->color[0][1] != Y || backF->color[0][1] != backF->color[1][1]){
        return 0;
    } else if (upF->color[1][0] != Y || leftF->color[0][1] != leftF->color[1][1]){
        return 0;
    } else if (upF->color[1][2] != Y || rightF->color[0][1] != rightF->color[1][1]){
        return 0;
    } else if (upF->color[2][1] != Y || frontF->color[0][1] != frontF->color[1][1]){
        return 0;
    } else {
        return 1;
    }
}

//verifie if the branch of the cross has the right color
int yellow_cross_branch (T_COLOR frontCol, T_COLOR rightCol, T_COLOR backCol, T_COLOR leftCol, Side *cube){
    for (int i = 0;i < 4;i++){
        switch (backCol){
        case R:
            if (leftCol == G){
                UP_anticlockwise(4 - i, cube);
                return 1;
            }
            break;
        case O:
            if (leftCol == B){
                UP_anticlockwise(4 - i, cube);
                return 1;
            }
            break;
        case G:
            if (leftCol == O){
                UP_anticlockwise(4 - i, cube);
                return 1;
            }
            break;
        case B:
            if (leftCol == R){
                UP_anticlockwise(4 - i, cube);
                return 1;
            }
            break;
        }
        UP_anticlockwise(1, cube);
    }
    return 0;
}

//put the corner at the right place
void yellow_corners (Side *rubiks){
    Side *upF = (rubiks + side_to_index(UP, rubiks));
    int bugSaver, i = 0;
    while (!verifie_yellow_corners(rubiks)){
        Side *frontF = (rubiks + side_to_index(FRONT, rubiks));
        Side *rightF = (rubiks + side_to_index(RIGHT, rubiks));
        if ((frontF->color[0][2] == frontF->color[1][1] || frontF->color[0][2] == rightF->color[1][1] || frontF->color[1][1] == Y) && (rightF->color[0][0] == rightF->color[1][1] || rightF->color[0][0] == frontF->color[1][1] || rightF->color[0][0] == Y) && (upF->color[2][2] == Y || upF->color[2][2] == frontF->color[1][1] || upF->color[2][2] == rightF->color[1][1])){
            place_corners(upF->color[2][0], frontF->color[0][0], rubiks);
            i = -1;
            break;
        } else if (i == 3){
            LEFT_anticlockwise(1, rubiks);
            UP_clockwise(1, rubiks);
            RIGHT_clockwise(1, rubiks);
            UP_anticlockwise(1, rubiks);
            LEFT_clockwise(1, rubiks);
            UP_clockwise(1, rubiks);
            RIGHT_anticlockwise(1, rubiks);
            UP_anticlockwise(1, rubiks);
            i = -1;
        }
        i++;
        half_horizontal_rotation_clockwise(rubiks);
    }
}

//verifie if the yellow corners are at the right place
int verifie_yellow_corners (Side *cube){
    Side *upF = (cube + side_to_index(UP, cube));
    Side *frontF = (cube + side_to_index(FRONT, cube));
    Side *rightF = (cube + side_to_index(RIGHT, cube));
    Side *backF = (cube + side_to_index(BACK, cube));
    Side *leftF = (cube + side_to_index(UP, cube));

    for (int i = 0;i < 4;i++){
        if (!((upF->color[0][0] == Y || upF->color[0][0] == leftF->color[1][1] || upF->color[0][0] == backF->color[1][1]) && (leftF->color[0][0] == Y || leftF->color[0][0] == leftF->color[1][1] || leftF->color[0][0] == backF->color[1][1]) && (backF->color[0][2] == Y || backF->color[0][2] == leftF->color[1][1] || backF->color[0][2] == backF->color[1][1]))){
            for (int j = 0;j < 4 - i;i++){
                half_horizontal_rotation_clockwise(cube);
            }
            return 0;
        }
        half_horizontal_rotation_clockwise(cube);
    }
    return 1;
}

//place the corners
void place_corners(T_COLOR upF, T_COLOR frontF, Side *cube){
    T_COLOR backF = (cube + side_to_index(BACK, cube))->color[1][1];
    Side *leftF = (cube + side_to_index(LEFT, cube));
    if ((frontF == leftF->color[1][1] || frontF == backF || frontF == Y) && (leftF->color[0][2] == backF || leftF->color[0][2] == leftF->color[1][1] || leftF->color[0][2] == Y) && (upF == backF || upF == leftF->color[1][1] || upF == Y)){
        LEFT_anticlockwise(1, cube);
        UP_clockwise(1, cube);
        RIGHT_clockwise(1, cube);
        UP_anticlockwise(1, cube);
        LEFT_clockwise(1, cube);
        UP_clockwise(1, cube);
        RIGHT_anticlockwise(1, cube);
        UP_anticlockwise(1, cube);
    } else {
        half_horizontal_rotation_clockwise(cube);
        RIGHT_clockwise(1, cube);
        UP_anticlockwise(1, cube);
        LEFT_anticlockwise(1, cube);
        UP_clockwise(1, cube);
        RIGHT_anticlockwise(1, cube);
        UP_anticlockwise(1, cube);
        LEFT_clockwise(1, cube);
        UP_clockwise(1, cube);
    }
}

//turn yellow corners on the right side
void turn_yellow_corners(Side *rubiks){
    Side *upF = (rubiks + side_to_index(UP, rubiks));
    Side *leftF = (rubiks + side_to_index(LEFT, rubiks));
    Side *frontF = (rubiks + side_to_index(FRONT, rubiks));
    Side *righF = (rubiks + side_to_index(RIGHT, rubiks));
    Side *backF = (rubiks + side_to_index(BACK, rubiks));
    int bugSaver = 0;
    while ((upF->color[0][0] != Y || upF->color[0][2] != Y || upF->color[2][0] != Y || upF->color[2][2] != Y) && bugSaver <= 100){
        if (upF->color[0][0] != Y && upF->color[0][2] == Y && upF->color[2][0] != Y && upF->color[2][2] == Y){
            if (leftF->color[0][0] == leftF->color[0][2]){
                horizontal_rotation(rubiks);
            } else if (upF->color[0][0] == upF->color[2][0]){
                half_vertical_rotation_clockwise(rubiks);
                half_horizontal_rotation_anticlockwise(rubiks);
                half_vertical_rotation_anticlockwise(rubiks);
            }
            main_algo(rubiks);
            white_UP(rubiks);
            vertical_rotation(rubiks);
        } else if (upF->color[0][0] != Y && upF->color[0][2] == Y && upF->color[2][0] != Y && upF->color[2][2] == Y){
            while (frontF->color[0][0] != Y ||frontF->color[0][2] != Y){
                half_horizontal_rotation_clockwise(rubiks);
            }
            main_algo(rubiks);
            FRONT_anticlockwise(1, rubiks);
        } else if (upF->color[0][0] == Y && upF->color[0][2] != Y && upF->color[2][0] != Y && upF->color[2][2] != Y){
            while (!(upF->color[0][0] == Y && leftF->color[0][2] == Y) && !(upF->color[2][0] == Y && righF->color[0][0] == Y)){
                half_horizontal_rotation_clockwise(rubiks);
            }
            main_algo(rubiks);
        } else if (upF->color[0][0] != Y && upF->color[0][2] != Y && upF->color[2][0] != Y && upF->color[2][2] != Y){
            while ((righF->color[0][0] != righF->color[0][1]) && (upF->color[0][2] != upF->color[2][2])){
                half_horizontal_rotation_clockwise(rubiks);
            }
            main_algo(rubiks);
        }
        display_rubiks(rubiks);
        printf("\n\n");
        ++bugSaver;
    }

    if (bugSaver > 100){
        printf("\n\nSomething went wrong by turning the yellow corners !\n\n");
    }
}

//it's the main algorithm of movement to do to put the yellow corners on the right way
void main_algo(Side *cube){
    RIGHT_clockwise(1, cube);
    UP_clockwise(2, cube);
    RIGHT_anticlockwise(1, cube);
    UP_anticlockwise(1, cube);
    RIGHT_clockwise(1, cube);
    UP_anticlockwise(1, cube);
    RIGHT_anticlockwise(1, cube);
    LEFT_anticlockwise(1, cube);
    UP_clockwise(2, cube);
    LEFT_clockwise(1, cube);
    UP_clockwise(1, cube);
    LEFT_anticlockwise(1, cube);
    UP_clockwise(1, cube);
    LEFT_clockwise(1, cube);
}

//show Menue
void Menu(Side *rubix) {
    int choix,mouv, clockwise, angle;
    printf("\n\n");
    printf("-----------------------------------------------------------------------------------------\n");
    printf("1: Scramble \t 2: Reset \t 3: Blank \t 4: Play \t 5: Fill \t 6: Solve\n7: QUIT\n");
    printf("-----------------------------------------------------------------------------------------\n");
    do {
        printf("Which operation do you want to realise?\n");
        scanf("%d", &choix);
    } while(choix < 1 || choix > 7);
    printf("You've choosed : %d\n\n", choix);
    switch(choix){
        case 1:
            scramble_rubiks(rubix);
            display_rubiks(rubix);
            Menu(rubix);
            break;
        case 2:
            init_rubiks(rubix);
            display_rubiks(rubix);
            Menu(rubix);
            break;
        case 3:
            blank_rubiks(rubix);
            display_rubiks(rubix);
            Menu(rubix);
            break;
        case 4:
            move_rubiks(rubix);
            break;
        case 5:
            blank_rubiks(rubix);
            display_rubiks(rubix);
            fill_rubiks(rubix);
            Menu(rubix);
            break;
        case 6:
            if (cell_empty(rubix)){
                display_rubiks(rubix);
                printf("\n\n");
                white_UP(rubix);
                display_rubiks(rubix);
                printf("\n\n");
                first_cross(rubix);
                display_rubiks(rubix);
                printf("\n\n");
                white_corners(rubix);
                display_rubiks(rubix);
                printf("\n\n");
                vertical_rotation(rubix);
                display_rubiks(rubix);
                printf("\n\n");
                second_crown(rubix);
                display_rubiks(rubix);
                printf("\n\n");
                yellow_cross(rubix);
                display_rubiks(rubix);
                printf("\n\n");
                yellow_corners(rubix);
                display_rubiks(rubix);
                printf("\n\n");
                turn_yellow_corners(rubix);
                display_rubiks(rubix);
            } else {
                printf("It seams that you still have an empty cell, please fill it or chose an other option.");
                printf("\n\n");
                display_rubiks(rubix);
            }
            Menu(rubix);
            break;
        case 7:
            ;
            break;
        default:
            Menu(rubix);
    }
}

//allow the user to do moves with the rubiks cube
void move_rubiks (Side *rubiks){
    int choiceF, choiceD;
    printf("\n\nWitch face do you want to rotate ? :\n-----------------------------------------------------------------------------------------\n\t1: UP \n2: LEFT \t 3: FRONT \t 4: RIGHT \t 5: BACK \t\n\t 6: DOWN \n\n 7: You may prefer to rotate the whole cube \t 8: QUIT\n-----------------------------------------------------------------------------------------\n");
    do
        scanf("%d", &choiceF);
    while (choiceF < 1 || choiceF > 8);
    if (choiceF < 6){
        printf("In witch direction do you want to turn ? :\n-----------------------------------------------------------------------------------------\n\t1: Clockwise \t 2: Anticlockwise\n-----------------------------------------------------------------------------------------\n");
        do
            scanf("%d", &choiceD);
        while (choiceD < 1 || choiceD > 2);
        switch (choiceF){
        case 1:
            switch (choiceD){
            case 1:
                UP_clockwise(1, rubiks);
                break;
            case 2:
                UP_anticlockwise(1, rubiks);
                break;
            }
            break;
        case 2:
            switch (choiceD){
            case 1:
                LEFT_clockwise(1, rubiks);
                break;
            case 2:
                LEFT_anticlockwise(1, rubiks);
                break;
            }
            break;
        case 3:
            switch (choiceD){
            case 1:
                FRONT_clockwise(1, rubiks);
                break;
            case 2:
                FRONT_anticlockwise(1, rubiks);
                break;
            }
            break;
        case 4:
            switch (choiceD){
            case 1:
                RIGHT_clockwise(1, rubiks);
                break;
            case 2:
                RIGHT_anticlockwise(1, rubiks);
                break;
            }
            break;
        case 5:
            switch (choiceD){
            case 1:
                BACK_clockwise(1, rubiks);
                break;
            case 2:
                BACK_anticlockwise(1, rubiks);
                break;
            }
            break;
        case 6:
            switch (choiceD){
            case 1:
                DOWN_clockwise(1, rubiks);
                break;
            case 2:
                DOWN_anticlockwise(1, rubiks);
                break;
            }
            break;
        }
        display_rubiks(rubiks);
        printf("\n\n");
        move_rubiks (rubiks);
    } else {
        switch (choiceF){
        case 7:
            printf("\n\nIn wich direction do you want to rotate the cube:\n-----------------------------------------------------------------------------------------\n\t1: Horizontal \n2: Vertical\n-----------------------------------------------------------------------------------------\n");
            do
                scanf("%d", &choiceD);
            while (choiceD < 1 || choiceD > 2);
            if (choiceD == 1)
                horizontal_rotation(rubiks);
            else
                vertical_rotation(rubiks);
            display_rubiks(rubiks);
            printf("\n\n");
            move_rubiks(rubiks);
            break;
        case 8:
            display_rubiks(rubiks);
            printf("\n\n");
            Menu(rubiks);
            break;
        }
    }
}

//allow the user to fill the rubik's cube by himself
void fill_rubiks(Side *rubiks){
    int face_choosen;
    int color_select;
    int cpt_white = 0;
    int cpt_yellow = 0;
    int cpt_blue = 0;
    int cpt_orange = 0;
    int cpt_red = 0;
    int cpt_green = 0;

    do {
        printf("\n\nChoose a face please: LEFT : 0    BACK : 1   RIGHT : 2    FRONT : 3    UP : 4    DOWN : 5\n");
        scanf("%d", &face_choosen);
    } while (face_choosen < 0 || face_choosen > 5);

    for(int i=0; i<3 ;i++){
        for(int j=0; j<3 ;j++){
            do{
                printf("\n\nChoose a color: RED : 0  BLUE : 1  GREEN : 2  ORANGE : 3   YELLOW : 4  WHITE : 5\n");
                scanf("%d", &color_select);
            }while(color_select < 0 || color_select > 5);
            if((color_select == 0)&& cpt_red<9){
                (rubiks + side_to_index(face_choosen, rubiks))->color[i][j] = color_select;
                cpt_red = cpt_red + 1;
                display_rubiks(rubiks);
                printf("\n\n");
            }
            if((color_select == 1)&& cpt_blue<9){
                (rubiks + side_to_index(face_choosen, rubiks))->color[i][j] = color_select;
                cpt_blue = cpt_blue + 1;
                display_rubiks(rubiks);
                printf("\n\n");
            }
            if((color_select == 2)&& cpt_green<9){
                (rubiks + side_to_index(face_choosen, rubiks))->color[i][j] = color_select;
                cpt_green = cpt_green + 1;
                display_rubiks(rubiks);
                printf("\n\n");
            }
            if((color_select == 3)&& cpt_orange<9){
                (rubiks + side_to_index(face_choosen, rubiks))->color[i][j] = color_select;
                cpt_orange = cpt_orange + 1;
                display_rubiks(rubiks);
                printf("\n\n");
            }
            if((color_select == 4)&& cpt_yellow<9){
                (rubiks + side_to_index(face_choosen, rubiks))->color[i][j] = color_select;
                cpt_yellow = cpt_yellow + 1;
                display_rubiks(rubiks);
                printf("\n\n");
            }
            if((color_select == 5)&& cpt_white<9){
                (rubiks + side_to_index(face_choosen, rubiks))->color[i][j] = color_select;
                cpt_white = cpt_white + 1;
                display_rubiks(rubiks);
                printf("\n\n");
            }
        }
    }
    printf("We continue ? [Y/N] : ");
    char choiceC;
    do
        scanf("%c", &choiceC);
    while (choiceC != 'Y' && choiceC != 'y' && choiceC != 'N' && choiceC != 'n');
    if (choiceC == 'Y')
        fill_rubiks(rubiks);
}

//verifie if a cell is empty
int cell_empty(Side *cube){
    for (int F = 0;F < 6;F++){
        Side *face = cube + side_to_index(F, cube);
        for (int i = 0;i < 3;i++){
            for (int j = 0;j < 3;j++){
                if (face->color[i][j] == LG)
                    return 0;
            }
        }
    }
    return 1;
}