#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#include "rubiks.h"

//ENUM TYPES FUNCTIONS
//return the value of the color of T_COLOR
int select_color (T_COLOR color){
    switch (color){
    case R:
        return 4;
        break;
    case B:
        return 1;
        break;
    case G:
        return 2;
        break;
    case W:
        return 15;
        break;
    case Y:
        return 6;
        break;
    case O:
        return 12;
        break;
    case LG:
        return 8;
        break;
    }
}

//return a char according the value of a T_COLOR
char ColorToChar (T_COLOR color){
    switch (color){
    case R:
        return 'R';
        break;
    case B:
        return 'B';
        break;
    case G:
        return 'G';
        break;
    case W:
        return 'W';
        break;
    case Y:
        return 'Y';
        break;
    case O:
        return 'O';
        break;
    case LG:
        return '#';
        break;
    }
}

//transform a color into a value
int side_to_index(T_SIDE side, Side *cube){
    for (int i = 0; i < 6; i++){
        if ((cube + i)->face == side){
            return i;
        }
    }
}

//CUBE REPRESENTATION FUNCTIONS
//create the general structure of the cube
Side *create_rubiks(){
    Side *rubiks = (Side *)calloc(6, sizeof(Side));
    blank_rubiks(rubiks);
    for (int i = 0; i < 6; i++){
        switch (i){
        case 0:
            (rubiks + i)->face = UP;
            break;
        case 1:
            (rubiks + i)->face = LEFT;
            break;
        case 2:
            (rubiks + i)->face = FRONT;
            break;
        case 3:
            (rubiks + i)->face = RIGHT;
            break;
        case 4:
            (rubiks + i)->face = BACK;
            break;
        case 5:
            (rubiks + i)->face = DOWN;
            break;
        }
    }
    return rubiks;
}

//initializes the rubik's cube in a resolved form
void init_rubiks(Side *rubiks){
    for (int i = 0; i < 6; i++){
        switch ((rubiks + i)->face){
        case FRONT:
            for (int j = 0; j < 3; j++){
                (rubiks + i)->color[j][0] = W;
                (rubiks + i)->color[j][1] = W;
                (rubiks + i)->color[j][2] = W;
            }
            break;
        case LEFT:
            for (int j = 0; j < 3; j++){
                (rubiks + i)->color[j][0] = O;
                (rubiks + i)->color[j][1] = O;
                (rubiks + i)->color[j][2] = O;
            }
            break;
        case RIGHT:
            for (int j = 0; j < 3; j++){
                (rubiks + i)->color[j][0] = R;
                (rubiks + i)->color[j][1] = R;
                (rubiks + i)->color[j][2] = R;
            }
            break;
        case UP:
            for (int j = 0; j < 3; j++){
                (rubiks + i)->color[j][0] = B;
                (rubiks + i)->color[j][1] = B;
                (rubiks + i)->color[j][2] = B;
            }
            break;
        case DOWN:
            for (int j = 0; j < 3; j++){
                (rubiks + i)->color[j][0] = G;
                (rubiks + i)->color[j][1] = G;
                (rubiks + i)->color[j][2] = G;
            }
            break;
        case BACK:
            for (int j = 0; j < 3; j++){
                (rubiks + i)->color[j][0] = Y;
                (rubiks + i)->color[j][1] = Y;
                (rubiks + i)->color[j][2] = Y;
            }
            break;
        }
    }
}

//select the color
void Color(int couleurDuTexte,int couleurDeFond){
    HANDLE H=GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(H,couleurDeFond*16+couleurDuTexte);
}

//display the rubik's cube
void display_rubiks(Side *cube){
    Side *upF = (cube + side_to_index(UP, cube));
    Side *leftF =(cube + side_to_index(LEFT, cube));
    Side *frontF =(cube + side_to_index(FRONT, cube));
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    Side *backF =(cube + side_to_index(BACK, cube));
    Side *downF =(cube + side_to_index(DOWN, cube));

    for (int i = 0; i < 3; i++){
        printf("      ");
        Color(select_color(upF->color[i][0]),0);
        printf("%c ", ColorToChar(upF->color[i][0]));
        Color(select_color(upF->color[i][1]),0);
        printf("%c ", ColorToChar(upF->color[i][1]));
        Color(select_color(upF->color[i][2]),0);
        printf("%c\n", ColorToChar(upF->color[i][2]));
    }
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 3; j++){
            Color(select_color(leftF->color[i][j]),0);
            printf("%c ", ColorToChar(leftF->color[i][j]));
        }
        for (int j = 0; j < 3; j++){
            Color(select_color(frontF->color[i][j]),0);
            printf("%c ", ColorToChar(frontF->color[i][j]));
        }
        for (int j = 0; j < 3; j++){
            Color(select_color(rightF->color[i][j]),0);
            printf("%c ", ColorToChar(rightF->color[i][j]));
        }
        Color(select_color(backF->color[i][0]),0);
        printf("%c ", ColorToChar(backF->color[i][0]));
        Color(select_color(backF->color[i][1]),0);
        printf("%c ", ColorToChar(backF->color[i][1]));
        Color(select_color(backF->color[i][2]),0);
        printf("%c\n", ColorToChar(backF->color[i][2]));
    }
    for (int i = 0; i < 3; i++){
        printf("      ");
        Color(select_color(downF->color[i][0]),0);
        printf("%c ", ColorToChar(downF->color[i][0]));
        Color(select_color(downF->color[i][1]),0);
        printf("%c ", ColorToChar(downF->color[i][1]));
        Color(select_color(downF->color[i][2]),0);
        printf("%c", ColorToChar(downF->color[i][2]));
        if (i != 2){
            printf("\n");
        }
    }
    Color(15,0);
}

//clear the rubik's colors
void blank_rubiks(Side * rubiks){
    for (int i = 0; i < 6; i++){
        for (int j = 0; j < 3; j++){
            (rubiks + i)->color[j][0] = LG;
            (rubiks + i)->color[j][1] = LG;
            (rubiks + i)->color[j][2] = LG;
        }
    }
}

//shuffle the cube with a number of move given by the user or a random one
void scramble_rubiks(Side *cube){
    int moves = 0;
    printf("How many random moves do you want (at least 1) ?\nIf you write a float it will be take only its integer part and if it's anything else it will be a random number between 100 and 1000 : ");
    scanf("%d", &moves);
    srand(time(NULL));
    if (!moves){
        moves = (rand() % 901) + 100;
    }
    for (moves; moves > 0; moves--){
        switch (rand() % 2){
        case 0:
            switch (rand() % 6){
            case 0:
                UP_clockwise((rand() % 2) + 1, cube);
                break;
            case 1:
                LEFT_clockwise((rand() % 2) + 1, cube);
                break;
            case 2:
                FRONT_clockwise((rand() % 2) + 1, cube);
                break;
            case 3:
                RIGHT_clockwise((rand() % 2) + 1, cube);
                break;
            case 4:
                BACK_clockwise((rand() % 2) + 1, cube);
                break;
            case 5:
                DOWN_clockwise((rand() % 2) + 1, cube);
                break;
            }
            break;
        case 1:
            switch (rand() % 6){
            case 0:
                UP_anticlockwise((rand() % 2) + 1, cube);
                break;
            case 1:
                LEFT_anticlockwise((rand() % 2) + 1, cube);
                break;
            case 2:
                FRONT_anticlockwise((rand() % 2) + 1, cube);
                break;
            case 3:
                RIGHT_anticlockwise((rand() % 2) + 1, cube);
                break;
            case 4:
                BACK_anticlockwise((rand() % 2) + 1, cube);
                break;
            case 5:
                DOWN_anticlockwise((rand() % 2) + 1, cube);
                break;
            }
            break;
        }
    }

    for (int i = 0; i < 3; i++){
        switch (rand() % 2)
        {
        case 0:
            horizontal_rotation(cube);
            break;
        case 1:
            vertical_rotation(cube);
            break;
        }
    }
}

//free memory space occupied by the cube
void free_rubiks(Side *rubiks){
    rubiks = NULL;
    free(rubiks);
}

//MOUVMENT FUNCTIONS
//faces  do a clockwise rotation :
//face UP
void UP_clockwise(int type, Side *cube){
    T_COLOR save[3];
    Side *upF =(cube + side_to_index(UP, cube));
    Side *leftF =(cube + side_to_index(LEFT, cube));
    Side *backF =(cube + side_to_index(BACK, cube));
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    Side *frontF =(cube + side_to_index(FRONT, cube));

    for (type; type > 0; type--){
        //rotate face UP cells
        save[0] = upF->color[1][0];
        save [1] = upF->color[0][0];
        for (int i = 0; i < 3; i++){
            upF->color[i][0] = upF->color[2][i];
        }
        for (int i = 0; i < 2; i++){
            upF->color[2][i + 1] = upF->color[1 - i][2];
        }
        upF->color[1][2] = upF->color[0][1];
        for (int i = 0; i < 2; i++){
            upF->color[0][i + 1] = save[i];
        }

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = leftF->color[0][i];
            leftF->color[0][i] = frontF->color[0][i];
            frontF->color[0][i] = rightF->color[0][i];
            rightF->color[0][i] = backF->color[0][i];
            backF->color[0][i] = save[i];
        }
    }
}

//face LEFT
void LEFT_clockwise(int type, Side *cube){
    T_COLOR save[3];
    int leftF = side_to_index(LEFT, cube);
    int backF = side_to_index(BACK, cube);
    int upF = side_to_index(UP, cube);
    int frontF = side_to_index(FRONT, cube);
    int downF = side_to_index(DOWN, cube);

    for (type; type > 0; type--){
        //rotate face LEFT cells
        save[0] = (cube + leftF)->color[1][0];
        save [1] = (cube + leftF)->color[0][0];
        for (int i = 0; i < 3; i++){
            (cube + leftF)->color[i][0] = (cube + leftF)->color[2][i];
        }
        for (int i = 0; i < 2; i++){
            (cube + leftF)->color[2][i + 1] = (cube + leftF)->color[1 - i][2];
        }
        (cube + leftF)->color[1][2] = (cube + leftF)->color[0][1];
        for (int i = 0; i < 2; i++){
            (cube + leftF)->color[0][i + 1] = save[i];
        }

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = (cube + backF)->color[2-i][2];
        }
        for (int i = 0; i < 3; i++){
            (cube + backF)->color[2-i][2] = (cube + downF)->color[i][0];
        }
        for (int i = 0; i < 3; i++){
            (cube + downF)->color[i][0] = (cube + frontF)->color[i][0];
        }
        for (int i = 0; i < 3; i++){
            (cube + frontF)->color[i][0] = (cube + upF)->color[i][0];
        }
        for (int i = 0; i < 3; i++){
            (cube + upF)->color[i][0] = save[i];
        }
    }
}

//face FRONT
void FRONT_clockwise(int type, Side *cube){
    T_COLOR save[3];
    int frontF = side_to_index(FRONT, cube);
    int leftF = side_to_index(LEFT, cube);
    int upF = side_to_index(UP, cube);
    Side *rightF = (cube + side_to_index(RIGHT, cube));
    int downF = side_to_index(DOWN, cube);

    for (type; type > 0; type--){
        //rotate face FRONT cells
        save[0] = (cube + frontF)->color[1][0];
        save [1] = (cube + frontF)->color[0][0];
        for (int i = 0; i < 3; i++){
            (cube + frontF)->color[i][0] = (cube + frontF)->color[2][i];
        }
        for (int i = 0; i < 2; i++){
            (cube + frontF)->color[2][i + 1] = (cube + frontF)->color[1 - i][2];
        }
        (cube + frontF)->color[1][2] = (cube + frontF)->color[0][1];
        for (int i = 0; i < 2; i++){
            (cube + frontF)->color[0][i + 1] = save[i];
        }

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = (cube + leftF)->color[2-i][2];
        }
        for (int i = 0; i < 3; i++){
            (cube + leftF)->color[i][2] = (cube + downF)->color[0][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + downF)->color[0][2 - i] = rightF->color[i][0];
        }
        for (int i = 0; i < 3; i++){
            rightF->color[i][0] = (cube + upF)->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + upF)->color[2][i] = save[i];
        }
    }
}

//face RIGHT
void RIGHT_clockwise(int type, Side *cube){
    T_COLOR save[3];
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    int frontF = side_to_index(FRONT, cube);
    int upF = side_to_index(UP, cube);
    int backF = side_to_index(BACK, cube);
    int downF = side_to_index(DOWN, cube);

    for (type; type > 0; type--){
        //rotate face RIGHT cells
        save[0] = rightF->color[1][0];
        save [1] = rightF->color[0][0];
        for (int i = 0; i < 3; i++){
            rightF->color[i][0] = rightF->color[2][i];
        }
        for (int i = 0; i < 2; i++){
            rightF->color[2][i + 1] = rightF->color[1 - i][2];
        }
        rightF->color[1][2] = rightF->color[0][1];
        for (int i = 0; i < 2; i++){
            rightF->color[0][i + 1] = save[i];
        }

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = (cube + frontF)->color[i][2];
        }
        for (int i = 0; i < 3; i++){
            (cube + frontF)->color[i][2] = (cube + downF)->color[i][2];
        }
        for (int i = 0; i < 3; i++){
            (cube + downF)->color[2 - i][2] = (cube + backF)->color[i][0];
        }
        for (int i = 0; i < 3; i++){
            (cube + backF)->color[2 - i][0] = (cube + upF)->color[i][2];
        }
        for (int i = 0; i < 3; i++){
            (cube + upF)->color[i][2] = save[i];
        }
    }
}

//face BACK
void BACK_clockwise(int type, Side *cube){
    T_COLOR save[3];
    int backF = side_to_index(BACK, cube);
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    int upF = side_to_index(UP, cube);
    int leftF = side_to_index(LEFT, cube);
    int downF = side_to_index(DOWN, cube);

    for (type; type > 0; type--){
        //rotate face BACK cells
        save[0] = (cube + backF)->color[1][0];
        save [1] = (cube + backF)->color[0][0];
        for (int i = 0; i < 3; i++){
            (cube + backF)->color[i][0] = (cube + backF)->color[2][i];
        }
        for (int i = 0; i < 2; i++){
            (cube + backF)->color[2][i + 1] = (cube + backF)->color[1 - i][2];
        }
        (cube + backF)->color[1][2] = (cube + backF)->color[0][1];
        for (int i = 0; i < 2; i++){
            (cube + backF)->color[0][i + 1] = save[i];
        }

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = rightF->color[i][2];
        }
        for (int i = 0; i < 3; i++){
            rightF->color[2 - i][2] = (cube + downF)->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + downF)->color[2][i] = (cube + leftF)->color[i][0];
        }
        for (int i = 0; i < 3; i++){
            (cube + leftF)->color[2 - i][0] = (cube + upF)->color[0][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + upF)->color[0][i] = save[i];
        }
    }
}

//face DOWN
void DOWN_clockwise(int type, Side *cube){
    T_COLOR save[3];
    int downF = side_to_index(DOWN, cube);
    int leftF = side_to_index(LEFT, cube);
    int frontF = side_to_index(FRONT, cube);
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    int backF = side_to_index(BACK, cube);

    for (type; type > 0; type--){
        //rotate face DOWN cells
        save[0] = (cube + downF)->color[1][0];
        save [1] = (cube + downF)->color[0][0];
        for (int i = 0; i < 3; i++){
            (cube + downF)->color[i][0] = (cube + downF)->color[2][i];
        }
        for (int i = 0; i < 2; i++){
            (cube + downF)->color[2][i + 1] = (cube + downF)->color[1 - i][2];
        }
        (cube + downF)->color[1][2] = (cube + downF)->color[0][1];
        for (int i = 0; i < 2; i++){
            (cube + downF)->color[0][i + 1] = save[i];
        }

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = (cube + leftF)->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + leftF)->color[2][i] = (cube + backF)->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + backF)->color[2][i] = rightF->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            rightF->color[2][i] = (cube + frontF)->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + frontF)->color[2][i] = save[i];
        }
    }
}

//faces  do an anticlockwise rotation :
//face UP
void UP_anticlockwise(int type, Side *cube){
    T_COLOR save[3];
    Side *upF = (cube + side_to_index(UP, cube));
    Side *leftF = (cube + side_to_index(LEFT, cube));
    Side *backF = (cube + side_to_index(BACK, cube));
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    Side *frontF = (cube + side_to_index(FRONT, cube));

    for (type; type > 0; type--){
        //rotate face UP cells
        save[0] = upF->color[1][0];
        save [1] = upF->color[2][0];
        for (int i = 0; i < 3; i++){
            upF->color[2 - i][0] = upF->color[0][i];
        }
        for (int i = 0; i < 2; i++){
            upF->color[0][i + 1] = upF->color[i + 1][2];
        }
        upF->color[1][2] = upF->color[2][1];
        for (int i = 0; i < 2; i++){
            upF->color[2][i + 1] = save[i];
        }
           

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = leftF->color[0][i];
            leftF->color[0][i] = backF->color[0][i];
            backF->color[0][i] = rightF->color[0][i];
            rightF->color[0][i] = frontF->color[0][i];
            frontF->color[0][i] = save[i];
        }
    }
}

//face LEFT
void LEFT_anticlockwise(int type, Side *cube){
    T_COLOR save[3];
    int leftF = side_to_index(LEFT, cube);
    int backF = side_to_index(BACK, cube);
    int upF = side_to_index(UP, cube);
    int frontF = side_to_index(FRONT, cube);
    int downF = side_to_index(DOWN, cube);

    for (type; type > 0; type--){
        //rotate face LEFT cells
        save[0] = (cube + leftF)->color[1][0];
        save [1] = (cube + leftF)->color[2][0];
        for (int i = 0; i < 3; i++){
            (cube + leftF)->color[2 - i][0] = (cube + leftF)->color[0][i];
        }
        for (int i = 0; i < 2; i++){
            (cube + leftF)->color[0][i + 1] = (cube + leftF)->color[i + 1][2];
        }
        (cube + leftF)->color[1][2] = (cube + leftF)->color[2][1];
        for (int i = 0; i < 2; i++){
            (cube + leftF)->color[2][i + 1] = save[i];
        }

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = (cube + backF)->color[2 - i][2];
        }
        for (int i = 0; i < 3; i++){
            (cube + backF)->color[2 - i][2] = (cube + upF)->color[i][0];
        }
        for (int i = 0; i < 3; i++){
            (cube + upF)->color[i][0] = (cube + frontF)->color[i][0];
        }
        for (int i = 0; i < 3; i++){
            (cube + frontF)->color[i][0] = (cube + downF)->color[i][0];
        }
        for (int i = 0; i < 3; i++){
            (cube + downF)->color[i][0] = save[i];
        }
    }
}

//face FRONT
void FRONT_anticlockwise(int type, Side *cube){
    T_COLOR save[3];
    int frontF = side_to_index(FRONT, cube);
    int leftF = side_to_index(LEFT, cube);
    int upF = side_to_index(UP, cube);
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    int downF = side_to_index(DOWN, cube);

    for (type; type > 0; type--){
        //rotate face FRONT cells
        save[0] = (cube + frontF)->color[1][0];
        save [1] = (cube + frontF)->color[2][0];
        for (int i = 0; i < 3; i++){
            (cube + frontF)->color[2 - i][0] = (cube + frontF)->color[0][i];
        }
        for (int i = 0; i < 2; i++){
            (cube + frontF)->color[0][i + 1] = (cube + frontF)->color[i + 1][2];
        }
        (cube + frontF)->color[1][2] = (cube + frontF)->color[2][1];
        for (int i = 0; i < 2; i++){
            (cube + frontF)->color[2][i + 1] = save[i];
        }

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = (cube + leftF)->color[i][2];
        }
        for (int i = 0; i < 3; i++){
            (cube + leftF)->color[2 - i][2] = (cube + upF)->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + upF)->color[2][i] = rightF->color[i][0];
        }
        for (int i = 0; i < 3; i++){
            rightF->color[i][0] = (cube + downF)->color[0][2 - i];
        }
        for (int i = 0; i < 3; i++){
            (cube + downF)->color[0][i] = save[i];
        }
    }
}

//face RIGHT
void RIGHT_anticlockwise(int type, Side *cube){
    T_COLOR save[3];
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    int frontF = side_to_index(FRONT, cube);
    int upF = side_to_index(UP, cube);
    int backF = side_to_index(BACK, cube);
    int downF = side_to_index(DOWN, cube);

    for (type; type > 0; type--){
        //rotate face RIGHT cells
        save[0] = rightF->color[1][0];
        save [1] = rightF->color[2][0];
        for (int i = 0; i < 3; i++){
            rightF->color[2 - i][0] = rightF->color[0][i];
        }
        for (int i = 0; i < 2; i++){
            rightF->color[0][i + 1] = rightF->color[i + 1][2];
        }
        rightF->color[1][2] = rightF->color[2][1];
        for (int i = 0; i < 2; i++){
            rightF->color[2][i + 1] = save[i];
        }

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = (cube + frontF)->color[i][2];
        }
        for (int i = 0; i < 3; i++){
            (cube + frontF)->color[i][2] = (cube + upF)->color[i][2];
        }
        for (int i = 0; i < 3; i++){
            (cube + upF)->color[i][2] = (cube + backF)->color[2 - i][0];
        }
        for (int i = 0; i < 3; i++){
            (cube + backF)->color[i][0] = (cube + downF)->color[2 - i][2];
        }
        for (int i = 0; i < 3; i++){
            (cube + downF)->color[i][2] = save[i];
        }
    }
}

//face BACK
void BACK_anticlockwise(int type, Side *cube){
    T_COLOR save[3];
    int backF = side_to_index(BACK, cube);
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    int upF = side_to_index(UP, cube);
    int leftF = side_to_index(LEFT, cube);
    int downF = side_to_index(DOWN, cube);

    for (type; type > 0; type--){
        //rotate face BACK cells
        save[0] = (cube + backF)->color[1][0];
        save [1] = (cube + backF)->color[2][0];
        for (int i = 0; i < 3; i++){
            (cube + backF)->color[2 - i][0] = (cube + backF)->color[0][i];
        }
        for (int i = 0; i < 2; i++){
            (cube + backF)->color[0][i + 1] = (cube + backF)->color[i + 1][2];
        }
        (cube + backF)->color[1][2] = (cube + backF)->color[2][1];
        for (int i = 0; i < 2; i++){
            (cube + backF)->color[2][i + 1] = save[i];
        }

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = rightF->color[2 - i][2];
        }
        for (int i = 0; i < 3; i++){
            rightF->color[i][2] = (cube + upF)->color[0][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + upF)->color[0][i] = (cube + leftF)->color[2 - i][0];
        }
        for (int i = 0; i < 3; i++){
            (cube + leftF)->color[i][0] = (cube + downF)->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + downF)->color[2][i] = save[i];
        }
    }
}

//face DOWN
void DOWN_anticlockwise(int type, Side *cube){
    T_COLOR save[3];
    int downF = side_to_index(DOWN, cube);
    int leftF = side_to_index(LEFT, cube);
    int frontF = side_to_index(FRONT, cube);
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    int backF = side_to_index(BACK, cube);

    for (type; type > 0; type--){
        //rotate face DOWN cells
        save[0] = (cube + downF)->color[1][0];
        save [1] = (cube + downF)->color[2][0];
        for (int i = 0; i < 3; i++){
            (cube + downF)->color[2 - i][0] = (cube + downF)->color[0][i];
        }
        for (int i = 0; i < 2; i++){
            (cube + downF)->color[0][i + 1] = (cube + downF)->color[i + 1][2];
        }
        (cube + downF)->color[1][2] = (cube + downF)->color[2][1];
        for (int i = 0; i < 2; i++){
            (cube + downF)->color[2][i + 1] = save[i];
        }

        //rotate crown cells
        for (int i = 0; i < 3; i++){
            save[i] = (cube + leftF)->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + leftF)->color[2][i] = (cube + frontF)->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + frontF)->color[2][i] = rightF->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            rightF->color[2][i] = (cube + backF)->color[2][i];
        }
        for (int i = 0; i < 3; i++){
            (cube + backF)->color[2][i] = save[i];
        }
    }
}

//rotation of the whole rubik's cube
void horizontal_rotation(Side *cube){
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    int backF = side_to_index(BACK, cube);
    (cube + side_to_index(LEFT, cube))->face = RIGHT;
    (cube + side_to_index(FRONT, cube))->face = BACK;
    rightF->face = LEFT;
    (cube + backF)->face = FRONT;
    int upF = side_to_index(UP, cube);
    int downF = side_to_index (DOWN, cube);
    T_COLOR save;
    for (int i = 0; i < 3; i++){
        save = (cube + upF)->color[0][i];
        (cube + upF)->color[0][i] = (cube + upF)->color[2][2 - i];
        (cube + upF)->color[2][2 - i] = save;
        save = (cube + downF)->color[0][i];
        (cube + downF)->color[0][i] = (cube + downF)->color[2][2 - i];
        (cube + downF)->color[2][2 - i] = save;
    }
    save = (cube + upF)->color[1][0];
    (cube + upF)->color[1][0] = (cube + upF)->color[1][2];
    (cube + upF)->color[1][2] = save;
    save = (cube + downF)->color[1][0];
    (cube + downF)->color[1][0] = (cube + downF)->color[1][2];
    (cube + downF)->color[1][2] = save;
}

void half_horizontal_rotation_clockwise(Side *cube){
    int backF = side_to_index(BACK, cube);
    int frontF = side_to_index(FRONT, cube);
    int upF = side_to_index(UP, cube);
    int downF = side_to_index(DOWN, cube);

    (cube + side_to_index(LEFT, cube))->face = BACK;
    (cube + side_to_index(RIGHT, cube))->face = FRONT;
    (cube + backF)->face = RIGHT;
    (cube + frontF)->face = LEFT;

    T_COLOR save [2];
    save[0] = (cube + upF)->color[1][0];
    save [1] = (cube + upF)->color[0][0];
    for (int i = 0; i < 3; i++){
        (cube + upF)->color[i][0] = (cube + upF)->color[2][i];
    }
    for (int i = 0; i < 2; i++){
        (cube + upF)->color[2][i + 1] = (cube + upF)->color[1 - i][2];
    }
    (cube + upF)->color[1][2] = (cube + upF)->color[0][1];
    for (int i = 0; i < 2; i++){
        (cube + upF)->color[0][i + 1] = save[i];
    }
    save[0] = (cube + downF)->color[1][0];
    save [1] = (cube + downF)->color[2][0];
    for (int i = 0; i < 3; i++){
        (cube + downF)->color[2 - i][0] = (cube + downF)->color[0][i];
    }
    for (int i = 0; i < 2; i++){
        (cube + downF)->color[0][i + 1] = (cube + downF)->color[i + 1][2];
    }
    (cube + downF)->color[1][2] = (cube + downF)->color[2][1];
    for (int i = 0; i < 2; i++){
        (cube + downF)->color[2][i + 1] = save[i];
    }
}

void half_horizontal_rotation_anticlockwise(Side *cube){
    int backF = side_to_index(BACK, cube);
    int frontF = side_to_index(FRONT, cube);
    int upF = side_to_index(UP, cube);
    int downF = side_to_index(DOWN, cube);

    (cube + side_to_index(LEFT, cube))->face = FRONT;
    (cube + side_to_index(RIGHT, cube))->face = BACK;
    (cube + backF)->face = LEFT;
    (cube + frontF)->face = RIGHT;

    T_COLOR save[2];
    save[0] = (cube + upF)->color[1][0];
    save [1] = (cube + upF)->color[2][0];
    for (int i = 0; i < 3; i++){
        (cube + upF)->color[2 - i][0] = (cube + upF)->color[0][i];
    }
    for (int i = 0; i < 2; i++){
        (cube + upF)->color[0][i + 1] = (cube + upF)->color[i + 1][2];
    }
    (cube + upF)->color[1][2] = (cube + upF)->color[2][1];
    for (int i = 0; i < 2; i++){
        (cube + upF)->color[2][i + 1] = save[i];
    }
    save[0] = (cube + downF)->color[1][0];
    save [1] = (cube + downF)->color[0][0];
    for (int i = 0; i < 3; i++){
        (cube + downF)->color[i][0] = (cube + downF)->color[2][i];
    }
    for (int i = 0; i < 2; i++){
        (cube + downF)->color[2][i + 1] = (cube + downF)->color[1 - i][2];
    }
    (cube + downF)->color[1][2] = (cube + downF)->color[0][1];
    for (int i = 0; i < 2; i++){
        (cube + downF)->color[0][i + 1] = save[i];
    }
}

void vertical_rotation(Side *cube){
    int downF = side_to_index(DOWN, cube);
    int backF = side_to_index(BACK, cube);
    (cube + side_to_index(UP, cube))->face = DOWN;
    (cube + side_to_index(FRONT, cube))->face = BACK;
    (cube + downF)->face = UP;
    (cube + backF)->face = FRONT;
    int lefF = side_to_index(LEFT, cube);
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    int prevFrontF = side_to_index(BACK, cube);
    T_COLOR save;
    for (int i = 0; i < 3; i++){
        save = (cube + lefF)->color[i][2];
        (cube + lefF)->color[i][2] = (cube + lefF)->color[2 - i][0];
        (cube + lefF)->color[2 - i][0] = save;
        save = rightF->color[i][2];
        rightF->color[i][2] = rightF->color[2 - i][0];
        rightF->color[2 - i][0] = save;
        save = (cube + backF)->color[i][2];
        (cube + backF)->color[i][2] = (cube + backF)->color[2 - i][0];
        (cube + backF)->color[2 - i][0] = save;
        save = (cube + prevFrontF)->color[i][2];
        (cube + prevFrontF)->color[i][2] = (cube + prevFrontF)->color[2 - i][0];
        (cube + prevFrontF)->color[2 - i][0] = save;
    }
    save = (cube + lefF)->color[0][1];
    (cube + lefF)->color[0][1] = (cube + lefF)->color[2][1];
    (cube + lefF)->color[2][1] = save;
    save = rightF->color[0][1];
    rightF->color[0][1] = rightF->color[2][1];
    rightF->color[2][1] = save;
    save = (cube + backF)->color[0][1];
    (cube + backF)->color[0][1] = (cube + backF)->color[2][1];
    (cube + backF)->color[2][1] = save;
    save = (cube + prevFrontF)->color[0][1];
    (cube + prevFrontF)->color[0][1] = (cube + prevFrontF)->color[2][1];
    (cube + prevFrontF)->color[2][1] = save;
}

void half_vertical_rotation_clockwise(Side *cube){
    int upF = side_to_index(UP, cube);
    int downF = side_to_index(DOWN, cube);
    int backF = side_to_index(BACK, cube);
    (cube + side_to_index(FRONT, cube))->face = DOWN;
    (cube + backF)->face = UP;
    (cube + downF)->face = BACK;
    (cube + upF)->face = FRONT;

    T_COLOR save [2];
    int leftF = side_to_index(LEFT, cube);
    Side *rightF =(cube + side_to_index(RIGHT, cube));
    for (int i = 0; i < 3; i++){
        save[0] = (cube + backF)->color[i][2];
        (cube + backF)->color[i][2] = (cube + backF)->color[2 - i][0];
        (cube + backF)->color[2 - i][0] = save[0];
        save[0] = (cube + downF)->color[i][2];
        (cube + downF)->color[i][2] = (cube + downF)->color[2 - i][0];
        (cube + downF)->color[2 - i][0] = save[0];
    }
    save[0] = (cube + backF)->color[0][1];
    (cube + backF)->color[0][1] = (cube + backF)->color[2][1];
    (cube + backF)->color[2][1] = save[0];
    save[0] = (cube + downF)->color[0][1];
    (cube + downF)->color[0][1] = (cube + downF)->color[2][1];
    (cube + downF)->color[2][1] = save[0];

    save[0] = (cube + leftF)->color[1][0];
    save [1] = (cube + leftF)->color[0][0];
    for (int i = 0; i < 3; i++){
        (cube + leftF)->color[i][0] = (cube + leftF)->color[2][i];
    }
    for (int i = 0; i < 2; i++){
        (cube + leftF)->color[2][i + 1] = (cube + leftF)->color[1 - i][2];
    }
    (cube + leftF)->color[1][2] = (cube + leftF)->color[0][1];
    for (int i = 0; i < 2; i++){
        (cube + leftF)->color[0][i + 1] = save[i];
    }
    save[0] = rightF->color[1][0];
    save [1] = rightF->color[2][0];
    for (int i = 0; i < 3; i++){
        rightF->color[2 - i][0] = rightF->color[0][i];
    }
    for (int i = 0; i < 2; i++){
        rightF->color[0][i + 1] = rightF->color[i + 1][2];
    }
    rightF->color[1][2] = rightF->color[2][1];
    for (int i = 0; i < 2; i++){
        rightF->color[2][i + 1] = save[i];
    }
}

void half_vertical_rotation_anticlockwise(Side *cube){
    int upF = side_to_index(UP, cube);
    int downF = side_to_index(DOWN, cube);
    int backF = side_to_index(BACK, cube);
    (cube + side_to_index(FRONT, cube))->face = UP;
    (cube + backF)->face = DOWN;
    (cube + upF)->face = BACK;
    (cube + downF)->face = FRONT;

    T_COLOR save [2];
    int leftF = side_to_index(LEFT, cube);
    Side *rightF = (cube + side_to_index(RIGHT, cube));
    for (int i = 0; i < 3; i++){
        save[0] = (cube + backF)->color[i][2];
        (cube + backF)->color[i][2] = (cube + backF)->color[2 - i][0];
        (cube + backF)->color[2 - i][0] = save[0];
        save[0] = (cube + upF)->color[i][2];
        (cube + upF)->color[i][2] = (cube + upF)->color[2 - i][0];
        (cube + upF)->color[2 - i][0] = save[0];
    }
    save[0] = (cube + backF)->color[0][1];
    (cube + backF)->color[0][1] = (cube + backF)->color[2][1];
    (cube + backF)->color[2][1] = save[0];
    save[0] = (cube + upF)->color[0][1];
    (cube + upF)->color[0][1] = (cube + upF)->color[2][1];
    (cube + upF)->color[2][1] = save[0];

    save[0] = (cube + leftF)->color[1][0];
    save [1] = (cube + leftF)->color[2][0];
    for (int i = 0; i < 3; i++){
        (cube + leftF)->color[2 - i][0] = (cube + leftF)->color[0][i];
    }
    for (int i = 0; i < 2; i++){
        (cube + leftF)->color[0][i + 1] = (cube + leftF)->color[i + 1][2];
    }
    (cube + leftF)->color[1][2] = (cube + leftF)->color[2][1];
    for (int i = 0; i < 2; i++){
        (cube + leftF)->color[2][i + 1] = save[i];
    }

    save[0] = rightF->color[1][0];
    save [1] = rightF->color[0][0];
    for (int i = 0; i < 3; i++){
        rightF->color[i][0] = rightF->color[2][i];
    }
    for (int i = 0; i < 2; i++){
        rightF->color[2][i + 1] = rightF->color[1 - i][2];
    }
    rightF->color[1][2] = rightF->color[0][1];
    for (int i = 0; i < 2; i++){
        rightF->color[0][i + 1] = save[i];
    }
}