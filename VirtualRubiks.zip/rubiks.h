//ENUMS
typedef enum {R, B, G, O, Y, W, LG} T_COLOR;
typedef enum {LEFT, BACK, RIGHT, FRONT, UP, DOWN} T_SIDE;

//STRUCTURES
typedef struct {
    T_COLOR color[3][3];
    T_SIDE face;
} Side;

//ENUM TYPES FUNCTIONS
int select_color (T_COLOR color);
char ColorToChar(T_COLOR col);
int side_to_index(T_SIDE side, Side *cube);

//CUBE REPRESENTATION FUNCTIONS
Side* create_rubiks ();
void init_rubiks (Side *cube);
void display_rubiks(Side *cube);
void blank_rubiks(Side * rubiks);
void scramble_rubiks(Side *cube);
void free_rubiks(Side *rubiks);

//MOUVMENT FUNCTIONS
//Clockwise
void UP_clockwise (int type, Side *cube);
void LEFT_clockwise (int type, Side *cube);
void FRONT_clockwise (int type, Side *cube);
void RIGHT_clockwise (int type, Side *cube);
void BACK_clockwise (int type, Side *cube);
void DOWN_clockwise (int type, Side *cube);

//anticlockwise
void UP_anticlockwise (int type, Side *cube);
void LEFT_anticlockwise (int type, Side *cube);
void FRONT_anticlockwise (int type, Side *cube);
void RIGHT_anticlockwise (int type, Side *cube);
void BACK_anticlockwise (int type, Side *cube);
void DOWN_anticlockwise (int type, Side *cube);

//rotate the rubik's cube
void horizontal_rotation (Side *cube);
void half_horizontal_rotation_clockwise(Side *cube);
void half_horizontal_rotation_anticlockwise(Side *cube);
void vertical_rotation (Side *cube);
void half_vertical_rotation_clockwise(Side *cube);
void half_vertical_rotation_anticlockwise(Side *cube);